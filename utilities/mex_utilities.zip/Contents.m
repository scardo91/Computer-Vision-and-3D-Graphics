% Utilities for MEX files
% Copyright 2008-2009 Levente Hunyadi
%
% Tools
%   make           - Automatized .c and .cpp into .mex file compilation.
%   readme         - Package description.
%
% Utility functions
%   dictionary     - A dictionary that stores name-value pairs.
